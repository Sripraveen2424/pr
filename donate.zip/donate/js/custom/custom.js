/*========================================== MASTER JAVASCRIPT ===================================================================

	Project     :	CONSTRUCTION LANDING PAGE
	Version     :	1.0
	Last Change : 	06/12/2019
	Primary Use :   CONSTRUCTION LANDING PAGE

=================================================================================================================================*/

$(document).on('ready', function() {
	"use strict"; //Start of Use Strict
		
	var menu_li = $('.navbar-nav li a');
    var collapse = $('.navbar-collapse');   
    var top_nav = $('#top-nav');
	
	$(window).scroll(function() {
	  var $header = $('#top-nav');
	  if ($(this).scrollTop() > 100) {
		if (!$header.hasClass('fixed-header')) $header.addClass("fixed-header");
	  } else {
		if ($header.hasClass('fixed-header')) $header.removeClass("fixed-header");
	  }
	});
	
 	//MENU BAR SMOOTH SCROLLING FUNCTION
    var menu_list = $('.navbar-nav');
    if (menu_list.length) {
        menu_list.on("click", ".nav-link", function(event) {
            event.stopPropagation();
            event.preventDefault();
			var t=200;			
			var windowWidth = $(window).width();
			if(windowWidth > 767){
				t=190;
			}else{
				t=190;
			}
			
			if( $('#top-nav').hasClass('fixed-header') ){
				t=90;
			}
            var hash_tag = $(this).attr('href');
            if ($(hash_tag).length) {
                $('html, body').animate({
                    scrollTop: $(hash_tag).offset().top - t
                }, 2000);

            }
			
            return false;
        });
    }
	

	
    //RESPONSIVE MENU SHOW AND HIDE FUNCTION
    if (menu_li.length) {
        menu_li.on("click", function(event) {
			var disp = $(".navbar-toggler").css('display'); 
			if( !$(".navbar-toggler").hasClass('collapsed') ){			
				if(collapse.hasClass('show')){
					collapse.removeClass('show').slideUp( "slow");
				}
			}            
        });    
    }	
		
    //CONTACT FORM VALIDATION	
    if ($('.contact-form').length) {
        $('.contact-form').each(function() {
            $(this).validate({
                errorClass: 'error',
                submitHandler: function(form) {
                    $.ajax({
                        type: "POST",
                        url: "mail/mail.php",
                        data: $(form).serialize(),
                        success: function(data) {
                            if (data) {
								$(form)[0].reset();
                                $('.sucessMessage').html('Mail Sent Successfully!!!');
                                $('.sucessMessage').show();
                                $('.sucessMessage').delay(3000).fadeOut();
                            } else {
                                $('.failMessage').html(data);
                                $('.failMessage').show();
                                $('.failMessage').delay(3000).fadeOut();
                            }
                        },
                        error: function(XMLHttpRequest, textStatus, errorThrown) {
                            $('.failMessage').html(textStatus);
                            $('.failMessage').show();
                            $('.failMessage').delay(3000).fadeOut();
                        }
                    });
                }
            });
        });
    }
	
    return false;
    // End of use strict
});