<?php
/**
 * This example shows sending a message using PHP's mail() function.
 */
require 'phpmailer/PHPMailerAutoload.php';
//Create a new PHPMailer instance
$mail = new PHPMailer;
if(isset($_POST['name']) && isset($_POST['phone']) && isset($_POST['email']) && isset($_POST['message']) ) {
	//Important - UPDATE YOUR RECEIVER EMAIL ID, NAME AND SUBJECT
		
	// Please enter your email ID 	
	$to_email = 'youremailid@keenicon.com';
	// Please enter your name		
	$to_name ="your name";
	// Please enter your Subject
	$subject="your Subject";
	
	$sender_name = $_POST['name'];
	$sender_phone = $_POST['phone'];
	$from_mail = $_POST['email'];	
	$sender_message = $_POST['message'];	
	$mail->SetFrom( $from_mail , $sender_name );
	$mail->AddReplyTo( $from_mail , $sender_name );
	$mail->AddAddress( $to_email , $to_name );
	$mail->Subject = $subject;
	
	$received_content = "SENDER NAME : ". $sender_name ."</br> SENDER PHONE : ".$sender_phone."</br> SENDER EMAIL : ".$from_mail. "</br> SENDER MESSAGE: </br/> ".$sender_message;
	
	$mail->MsgHTML( $received_content );
	
	echo $mail->Send();
	exit;	
}